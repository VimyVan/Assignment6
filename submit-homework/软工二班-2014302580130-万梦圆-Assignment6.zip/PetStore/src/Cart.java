import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Cart extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cart frame = new Cart();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	/**
	 * Create the frame.
	 */
	public Cart() {
		MySql sql=new MySql();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 398);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		Object[][] info = null;
		String[]names = null;
		try {			
			Statement st=sql.connect.createStatement();
			ResultSet rs=st.executeQuery("select count(*) from 2014302580130_cart");
			rs.next();
			int RowNum=rs.getInt(1);
			rs=st.executeQuery("select * from 2014302580130_cart");
			ResultSetMetaData rsmd=rs.getMetaData();
			int ColNum=rsmd.getColumnCount();
			
			names=new String[ColNum];
			for(int i=0;i<ColNum;i++){
				names[i]=rsmd.getColumnName(i+1);
			}
			info=new Object[RowNum][];
			int i=0;
			while(rs.next()){
				info[i]=new Object[ColNum];
				for(int j=0;j<ColNum;j++){
					info[i][j]=rs.getObject(j+1);
				}
				i++;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DefaultTableModel tableModel=new DefaultTableModel(info,names){
			public boolean isCellEditable(int row,int column){
				if(column!=2){return false;}
				else{return true;}	
		}};
	    table=new JTable(tableModel);
		
		
		
		JLabel lblList = new JLabel("List");
		
		JLabel lblId = new JLabel("ID");
		
		JLabel lblName = new JLabel("Name");
		
		JLabel lblNum = new JLabel("Num");
		
		JLabel lblPrice = new JLabel("Price");
		
		JLabel lblCost = new JLabel("Cost");
		
		JLabel total = new JLabel("o");
		total.setFont(new Font("����", Font.PLAIN, 17));
		
		JButton btnTotal = new JButton("Total");
		btnTotal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//table.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE); ��һ����Ч
				if(table.isEditing()){
					table.getCellEditor().stopCellEditing();
				}
				int [] price=new int[12];
				int tm=0;
				try 
				{
					int rows=table.getRowCount();
				    int cols=table.getColumnCount();
					String []c=new String[cols];
					for(int i=0;i<rows;i++){
						   for(int j=0;j<cols;j++){
							   c[j]=String.valueOf(table.getValueAt(i, j));
						}
						PreparedStatement psql;
						psql=sql.connect.prepareStatement("update 2014302580130_cart set amount=? , money=? where name=? ");
						psql.setString(3, c[1]);
						psql.setInt(2,Integer.parseInt(c[2])*Integer.parseInt(c[3]));
						psql.setInt(1,Integer.parseInt(c[2]));
						psql.executeUpdate();
						table.setValueAt(Integer.parseInt(c[2])*Integer.parseInt(c[3]), i, 4);
						
					}
					
					Statement stmt;
					stmt = sql.connect.createStatement();
				    ResultSet rs;
					rs = stmt.executeQuery("SELECT money FROM 2014302580130_cart");
					int i=0;
					while(rs.next()){
						tm+=rs.getInt(1);	
						i++;
					}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();} 
				
				total.setText(String.valueOf(tm));
			}
		});
		
		JLabel label = new JLabel("$");
		
		JButton btnVerifyPurchase = new JButton("Verify Purchase");
		btnVerifyPurchase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int rows=table.getRowCount();
			    int cols=table.getColumnCount();
				String []c=new String[cols];
				for(int i=0;i<rows;i++){
					   for(int j=0;j<cols;j++){
						   c[j]=String.valueOf(table.getValueAt(i, j));
					}
					
					try {
						int amount;
						int initial = 0;
						Statement stmt;
						stmt = sql.connect.createStatement();
					    ResultSet rs;
						rs = stmt.executeQuery("SELECT * FROM 2014302580130_pet");
						while(rs.next()){
							if (rs.getString(2).equals(c[1]))
							{
								initial=rs.getInt(8);}
						}
						amount=initial-Integer.parseInt(c[2]);
						PreparedStatement psql;
						psql=sql.connect.prepareStatement("update 2014302580130_pet set inventary=? where name=? ");
						psql.setString(2, c[1]);
						psql.setInt(1,amount);
						psql.executeUpdate();
						table.setValueAt(Integer.parseInt(c[2])*Integer.parseInt(c[3]), i, 4);
						
						psql=sql.connect.prepareStatement("delete from 2014302580130_cart");
						psql.executeUpdate();
						tableModel.setRowCount(0);
						table=new JTable(tableModel);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();} 
						
				}
			}
		});
		
		JButton btnReturn = new JButton("Return");
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Store frame = new Store();
				frame.setVisible(true);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(table, GroupLayout.PREFERRED_SIZE, 205, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(btnVerifyPurchase, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnTotal, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(24)
									.addComponent(total, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
									.addGap(31)
									.addComponent(label))
								.addComponent(btnReturn, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGap(46))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblList)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblId)
									.addGap(31)
									.addComponent(lblName)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(lblNum)
									.addGap(10)
									.addComponent(lblPrice)
									.addGap(18)
									.addComponent(lblCost)))
							.addContainerGap(237, Short.MAX_VALUE))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(14, Short.MAX_VALUE)
					.addComponent(lblList)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblId)
						.addComponent(lblName)
						.addComponent(lblNum)
						.addComponent(lblCost)
						.addComponent(lblPrice))
					.addGap(5)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnTotal)
							.addGap(29)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(label)
								.addComponent(total))
							.addGap(27)
							.addComponent(btnVerifyPurchase)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(btnReturn))
						.addComponent(table, GroupLayout.PREFERRED_SIZE, 197, GroupLayout.PREFERRED_SIZE))
					.addGap(93))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
