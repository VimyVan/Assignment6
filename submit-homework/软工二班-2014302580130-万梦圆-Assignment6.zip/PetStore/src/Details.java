import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class Details extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Details frame = new Details();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public Details(String pet) {
		Pets myPet=new Pets(pet);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 495, 352);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblPet = new JLabel("pet:");
		
		JLabel lblName = new JLabel(myPet.name);
		
		JLabel lblEat = new JLabel("eat:");
		
		JLabel lblFood = new JLabel(myPet.eat);
		
		JLabel lblDrink = new JLabel("drink:");
		
		JLabel lblDrink_1 = new JLabel(myPet.drink);
		
		JLabel lblLive = new JLabel("live:");
		
		JLabel lblPlace = new JLabel(myPet.live);
		
		JLabel lblHobby = new JLabel("hobby:");
		
		JLabel lblPlay = new JLabel(myPet.hobby);
		
		JLabel lblAmount = new JLabel("inventary:");
		
		JLabel label = new JLabel(myPet.inventory);
		
		JLabel lblPrice = new JLabel("price:");
		
		JLabel label_1 = new JLabel(myPet.price);
		
		JButton btnBuyIt = new JButton("Buy it");
		btnBuyIt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					MySql sql=new MySql();
					int amount=0;
					int money=0;
					Statement stmt;
					stmt = sql.connect.createStatement();
				    ResultSet rs;
					rs = stmt.executeQuery("SELECT * FROM 2014302580130_cart");
					boolean exist=false;
					while(rs.next()){
						if (rs.getString(2).equals(lblName.getText()))
						{
							amount=Integer.parseInt(textField.getText())+rs.getInt(3);
							money=rs.getInt(4)*amount;
							exist=true;
							PreparedStatement psql;
							psql=sql.connect.prepareStatement("update 2014302580130_cart set amount=? , money=? where name=? ");
							psql.setString(3, lblName.getText());
							psql.setInt(2,money);
							psql.setInt(1,amount);
							psql.executeUpdate();
							}
						
					}
					if(exist==false){
						Statement st=sql.connect.createStatement();
						rs=st.executeQuery("select count(*) from 2014302580130_cart");
						rs.next();
						int RowNum=rs.getInt(1);
						PreparedStatement psql;
						psql=sql.connect.prepareStatement("insert into 2014302580130_cart values(?,?,?,?,?)");
						psql.setInt(1,RowNum+1);
						psql.setString(2, lblName.getText());
						int i=Integer.parseInt(textField.getText());
						psql.setInt(3, i);
						int j=Integer.parseInt(myPet.price);
						psql.setInt(4,j);
						psql.setInt(5,i*j);
						psql.executeUpdate();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		textField = new JTextField();
		textField.setColumns(10);
		
		JLabel lblAmountsOfPets = new JLabel("amounts of pets you purchase:");
		
		JButton btnReturn = new JButton("Return");
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Store frame = new Store();
				frame.setVisible(true);
			}
		});
		
		JButton btnCart = new JButton("Cart");
		btnCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Cart frame = new Cart();
				frame.setVisible(true);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblHobby)
								.addComponent(lblAmount))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblPlay)
								.addComponent(label_1)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
									.addComponent(lblPlace)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblFood)
										.addComponent(lblDrink_1)
										.addComponent(lblName)))
								.addComponent(label, GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)))
						.addComponent(lblPrice)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblPet)
								.addComponent(lblEat)
								.addComponent(lblDrink)
								.addComponent(lblLive))
							.addPreferredGap(ComponentPlacement.RELATED, 112, Short.MAX_VALUE)))
					.addPreferredGap(ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblAmountsOfPets)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
									.addComponent(btnCart, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(btnReturn, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)))
							.addGap(60))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(btnBuyIt)
							.addGap(25)))
					.addGap(25))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblPet)
								.addComponent(lblName))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblEat)
								.addComponent(lblFood))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblDrink)
								.addComponent(lblDrink_1))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblLive)
								.addComponent(lblPlace)
								.addComponent(btnCart)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(54)
							.addComponent(btnReturn)))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblHobby)
						.addComponent(lblPlay))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAmount)
						.addComponent(label)
						.addComponent(lblAmountsOfPets))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPrice)
						.addComponent(label_1)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnBuyIt))
					.addContainerGap(72, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
