import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class MySql {
	Connection connect;
	public boolean userExst=false;
	public MySql()
	{
		try {
			 Class.forName("com.mysql.jdbc.Driver");
			 System.out.println("Success loading Mysql Driver!"); 
			 } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
				 e.printStackTrace();
				 }  
		
		try {
			//connect = DriverManager.getConnection(
			//		"jdbc:mysql://localhost:3306/pet","root","19960921");
				connect = DriverManager.getConnection(  
				          "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
				System.out.println("Success connect Mysql server!"); 
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
	}
	
	public boolean Login(String username,String password)
	{
		
		String psw=null;
		try 
		{
			Statement stmt;
			stmt = connect.createStatement();
		    ResultSet rs;
			rs = stmt.executeQuery("SELECT * FROM 2014302580130_user");
			while(rs.next()){
				if (rs.getString(2).equals(username))
				{
					userExst=true;
					psw=rs.getString(3);}
			}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();} 
			while(psw!=null){
				if(psw.equals(password)){
					return true;
				}
				else{return false;}
			}
			return false; 			
	}
	
	public void signIn(String username,String password)
	{		
		try {
			PreparedStatement psql;
			psql=connect.prepareStatement("insert into 2014302580130_user values(null,?,?)");
			psql.setString(1, username);
			psql.setString(2, password);
			psql.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	


}
