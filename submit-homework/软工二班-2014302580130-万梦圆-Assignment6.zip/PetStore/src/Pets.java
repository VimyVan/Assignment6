import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Pets {
	public String name;
	public String eat;
	public String drink;
	public String live;
	public String hobby;
	public String price;
	public String inventory;
	
	public Pets(String pet){
		MySql sql=new MySql();
		try {
			Statement stmt;
			stmt = sql.connect.createStatement();
			ResultSet rs;
		    rs = stmt.executeQuery("SELECT * FROM 2014302580130_pet");
			while(rs.next()){
				if (rs.getString(2).equals(pet)){
					this.name=rs.getString(2);
					this.eat=rs.getString(3);
					this.drink=rs.getString(4);
					this.live=rs.getString(5);
					this.hobby=rs.getString(6);
					this.price=rs.getString(7);
					this.inventory=rs.getString(8);
				}
				}
			} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();} 
			
		
		
	}

}
