import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Store extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
/*	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Store frame = new Store();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	/**
	 * Create the frame.
	 */
	public Store() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 365);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblPet = new JLabel("pet");
		lblPet.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		lblPet.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblPrice = new JLabel("price");
		lblPrice.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		lblPrice.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblDog = new JLabel("dog");
		
		JLabel label_2 = new JLabel("100");
		
		JLabel lblCat = new JLabel("cat");
		
		JLabel label_3 = new JLabel("150");
		
		JLabel lblTurtle = new JLabel("turtle");
		
		JLabel label_4 = new JLabel("50");
		
		JLabel lblParrot = new JLabel("parrot");
		
		JLabel label_5 = new JLabel("80");
		
		JLabel lblHamster = new JLabel("hamster");
		
		JLabel label_6 = new JLabel("120");
		
		JLabel lblSquirrel = new JLabel("squirrel");
		
		JLabel label_7 = new JLabel("300");
		
		JLabel lblRabbit = new JLabel("rabbit");
		
		JLabel label_8 = new JLabel("50");
		
		JLabel lblSnake = new JLabel("snake");
		
		JLabel label_9 = new JLabel("30");
		
		JLabel lblLizard = new JLabel("lizard");
		
		JLabel label_10 = new JLabel("20");
		
		JLabel lblFish = new JLabel("fish");
		
		JLabel label_11 = new JLabel("10");
		
		JLabel lblMyna = new JLabel("myna");
		
		JLabel label_12 = new JLabel("70");
		
		JLabel lblNewLabel = new JLabel("canary");
		
		JLabel label_13 = new JLabel("90");
		
		JButton dog = new JButton("details");
		dog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Details frame = new Details("dog");
				frame.setVisible(true);
			}
		});
		dog.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton cat = new JButton("details");
		cat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Details frame = new Details("cat");
				frame.setVisible(true);
			}
		});
		cat.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton turtle = new JButton("details");
		turtle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Details frame = new Details("turtle");
				frame.setVisible(true);
			}
		});
		turtle.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton parrot = new JButton("details");
		parrot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Details frame = new Details("parrot");
				frame.setVisible(true);
			}
		});
		parrot.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton hamster = new JButton("details");
		hamster.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Details frame = new Details("hamster");
				frame.setVisible(true);
			}
		});
		hamster.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton squirrel = new JButton("details");
		squirrel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Details frame = new Details("squirrel");
				frame.setVisible(true);
			}
		});
		squirrel.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton rabbit = new JButton("details");
		rabbit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Details frame = new Details("rabbit");
				frame.setVisible(true);
			}
		});
		rabbit.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton snake = new JButton("details");
		snake.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Details frame = new Details("snake");
				frame.setVisible(true);
			}
		});
		snake.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton lizard = new JButton("details");
		lizard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Details frame = new Details("lizard");
				frame.setVisible(true);
			}
		});
		lizard.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton fish = new JButton("details");
		fish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Details frame = new Details("fish");
				frame.setVisible(true);
			}
		});
		fish.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton myna = new JButton("details");
		myna.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Details frame = new Details("myna");
				frame.setVisible(true);
			}
		});
		myna.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton canary = new JButton("details");
		canary.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Details frame = new Details("canary");
				frame.setVisible(true);
			}
		});
		canary.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JLabel label = new JLabel("pet");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JLabel label_1 = new JLabel("price");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		
		JButton btnCart = new JButton("Cart");
		btnCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Cart frame = new Cart();
				frame.setVisible(true);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblPet)
										.addComponent(lblDog)
										.addComponent(lblCat)
										.addComponent(lblTurtle)
										.addComponent(lblParrot))
									.addGap(24)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblPrice)
										.addComponent(label_2)
										.addComponent(label_3)
										.addComponent(label_4)
										.addComponent(label_5)))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblHamster)
									.addGap(18)
									.addComponent(label_6))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblSquirrel)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(label_7)))
							.addPreferredGap(ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(squirrel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(hamster, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(dog, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(cat, GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE)
									.addPreferredGap(ComponentPlacement.UNRELATED))
								.addComponent(parrot, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(turtle, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGap(10)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addPreferredGap(ComponentPlacement.RELATED)
											.addComponent(lblNewLabel)
											.addGap(18)
											.addComponent(label_13))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
												.addComponent(lblRabbit)
												.addComponent(lblSnake)
												.addComponent(label, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE))
											.addGap(18)
											.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
												.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
												.addComponent(label_8)
												.addComponent(label_9))))
									.addGap(8)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addComponent(rabbit, GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE)
										.addComponent(snake, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lizard, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(fish, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(myna, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(canary, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblLizard)
										.addComponent(lblFish)
										.addComponent(lblMyna))
									.addGap(18)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(label_12)
										.addComponent(label_11)
										.addComponent(label_10))))
							.addGap(19))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnCart)
							.addGap(38))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPet)
						.addComponent(lblPrice)
						.addComponent(label)
						.addComponent(label_1))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblDog)
						.addComponent(label_2)
						.addComponent(lblRabbit)
						.addComponent(label_8)
						.addComponent(dog)
						.addComponent(rabbit))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCat)
						.addComponent(label_3)
						.addComponent(lblSnake)
						.addComponent(label_9)
						.addComponent(cat)
						.addComponent(snake))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTurtle)
						.addComponent(label_4)
						.addComponent(lblLizard)
						.addComponent(label_10)
						.addComponent(turtle)
						.addComponent(lizard))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblParrot)
						.addComponent(label_5)
						.addComponent(lblFish)
						.addComponent(label_11)
						.addComponent(parrot)
						.addComponent(fish))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblHamster)
						.addComponent(label_6)
						.addComponent(lblMyna)
						.addComponent(label_12)
						.addComponent(hamster)
						.addComponent(myna))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(canary)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblSquirrel)
							.addComponent(label_7)
							.addComponent(squirrel)
							.addComponent(lblNewLabel)
							.addComponent(label_13)))
					.addPreferredGap(ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
					.addComponent(btnCart)
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}

}
